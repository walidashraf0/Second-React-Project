import React from 'react';
import styles from './Categories.module.css';

export default function Categories() {
  return <>
    <h1>Categories</h1>
  </>
}
