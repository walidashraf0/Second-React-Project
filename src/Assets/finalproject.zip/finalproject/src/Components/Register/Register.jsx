import React from 'react';
import styles from './Register.module.css';

export default function Register() {
  return <>
    <h1>Register</h1>
  </>
}
