import React from 'react';
import styles from './Login.module.css';

export default function Login() {
  return <>
    <h1>Login</h1>
  </>
}
